Kemal Holubeshen Kemal.holubeshen@gmail.com A01029288
Khide Hoskins Khidehoskins@gmail.com A01030177
Nov 26 2017

We have completed everything but the slider, having the javascript
separate, and having our contact info on the website.